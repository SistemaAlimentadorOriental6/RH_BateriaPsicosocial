import pandas as pd
import sqlite3
import numpy as np
import os
from openpyxl import load_workbook
from openpyxl.styles import Alignment,Border,Side,PatternFill,Font

from clasificaciones import (
    clasificacion_estres_A, clasificacion_estres_B,
    CLASIFICACION_CUESTIONARIO_A, CLASIFICACION_CUESTIONARIO_B,
    CLASIFICACION_CUESTIONARIO_E, CLASIFICACION_CUESTIONARIOS, CLASIFICACION_DOMINIOS_A, CLASIFICACION_DOMINIOS_B,
    CLASIFICACION_DIMENSIONES_A, CLASIFICACION_DIMENSIONES_B, CLASIFICACION_DIMENSIONES_E)




''' 1. Unión de las tablas 'usuarios', 'evaluaciones', 'dimensiones' y 'dominios (para sacar las dimensiones del extralaboral)' 
(para poder tener la información del resultado del puntaje_transformado por área y por tipo de empleado (A o B))'''




# Conectar a la base de datos
conn = sqlite3.connect('../data/evaluacion_psicosocial.db')

# Leer las tablas de interés
evaluaciones_df = pd.read_sql("SELECT * FROM evaluaciones", conn)
dimensiones_df = pd.read_sql("SELECT * FROM dimensiones", conn)
usuarios_df = pd.read_sql("SELECT * FROM usuarios", conn)
dominios_df = pd.read_sql("SELECT * FROM dominios", conn)

# AQUÍ SE SACAN LAS DIMENSIONES DEL EXTRALABORAL QUE SE ESTÁN GUARDANDO EN LA TABLA DOMINIO **
valores_a_excluir = [
    "Control sobre el trabajo",
    "Demandas del trabajo",
    "Liderazgo y relaciones sociales en el trabajo",
    "Recompensas"
]
dominios_df = dominios_df[~dominios_df['dominio'].isin(valores_a_excluir)]

dominios_df.rename(columns={'dominio': 'dimension'}, inplace=True)

# Se seleccionan solo las columnas de interés de la tabla usuarios para anonimizar los usuarios y no traer nombres y cédulas
usuarios_df = usuarios_df[['id', 'area']]

# Cambiar el nombre de la columna 'id' a 'usuario_id' en la tabla usuarios para poder hacer la union de las tablas
usuarios_df.rename(columns={'id': 'usuario_id'}, inplace=True)

# Aquí se concatenan las tablas dominios con dimensiones para agregar las dimensiones del extralaboral que se guardaron en dominios **
columnas_comunes = ['id', 'resultado_id', 'usuario_id', 'dimension', 'puntaje_bruto', 'puntaje_transformado', 'clasificacion']
dimensiones_y_dominios = pd.concat([dimensiones_df[columnas_comunes], dominios_df[columnas_comunes]], ignore_index=True)

# Unión de las tablas
dimensiones_con_evaluaciones = pd.merge(dimensiones_y_dominios, evaluaciones_df, on='usuario_id', how='inner')

dimensiones_evaluaciones_y_usuarios = pd.merge(dimensiones_con_evaluaciones, usuarios_df, on='usuario_id', how='inner')

# Cerrar la conexión
conn.close()

# Convertir la columna 'tipo_empleado' a mayúsculas
dimensiones_evaluaciones_y_usuarios['tipo_empleado'] = dimensiones_evaluaciones_y_usuarios['tipo_empleado'].str.upper()



# Reemplazar 'Sin puntaje válido' por NaN ya que de lo contrario no se podrá sacar promedio
dimensiones_evaluaciones_y_usuarios['puntaje_transformado'] = dimensiones_evaluaciones_y_usuarios['puntaje_transformado'].replace('Sin puntaje válido', pd.NA)

# Convertir 'puntaje_transformado' a tipo float (esto convertirá 'NaN' a NaN para no afectar el cálculo del promedio)
dimensiones_evaluaciones_y_usuarios['puntaje_transformado'] = pd.to_numeric(dimensiones_evaluaciones_y_usuarios['puntaje_transformado'], errors='coerce')


# Se saca el promedio por dimension, tipo empleado y área
dimensiones_evaluaciones_y_usuarios = dimensiones_evaluaciones_y_usuarios.groupby(['dimension', 'tipo_empleado', 'area']).agg({
    'puntaje_transformado': 'mean'
}).reset_index()

# Se redondea el resultado de 'puntaje_transformado' a un decimal
dimensiones_evaluaciones_y_usuarios['puntaje_transformado'] = dimensiones_evaluaciones_y_usuarios['puntaje_transformado'].round(1)



'''2. Unión de las tablas 'usuarios', 'evaluaciones', 'dominios' 
(para poder tener la información del resultado del puntaje_transformado por área y por tipo de empleado (A o B))'''

# Conectar a la base de datos
conn = sqlite3.connect('../data/evaluacion_psicosocial.db')

# Leer las tablas de interés
evaluaciones2_df = pd.read_sql("SELECT * FROM evaluaciones", conn)
dominios_df = pd.read_sql("SELECT * FROM dominios", conn)
usuarios2_df = pd.read_sql("SELECT * FROM usuarios", conn)

# columnas de interés de la tabla usuarios para anonimizar datos personales
usuarios2_df = usuarios2_df[['id', 'area']]

# Cambiar el nombre de la columna 'id' a 'usuario_id' en la tabla usuarios 
usuarios2_df.rename(columns={'id': 'usuario_id'}, inplace=True)

# Unir las tablas por 'usuario_id'
dominios_con_evaluaciones = pd.merge(dominios_df, evaluaciones2_df, on='usuario_id', how='inner')
dominios_evaluaciones_y_usuarios = pd.merge(dominios_con_evaluaciones, usuarios2_df, on='usuario_id', how='inner')


conn.close()

#Convertir a mayúsculas los valores de la columna tipo_empleado
dominios_evaluaciones_y_usuarios['tipo_empleado'] = dominios_evaluaciones_y_usuarios['tipo_empleado'].str.upper()

# Reemplazar 'Sin puntaje válido' por NaN de lo contrario no se puede hacer el promedio
dominios_evaluaciones_y_usuarios['puntaje_transformado'] = dominios_evaluaciones_y_usuarios['puntaje_transformado'].replace('Sin puntaje válido', pd.NA)

dominios_evaluaciones_y_usuarios['puntaje_transformado'] = pd.to_numeric(dominios_evaluaciones_y_usuarios['puntaje_transformado'], errors='coerce')



#Se saca el promedio por dominio, tipo empleado y área
dominios_evaluaciones_y_usuarios = dominios_evaluaciones_y_usuarios.groupby(['dominio', 'tipo_empleado', 'area']).agg({
    'puntaje_transformado': 'mean'
}).reset_index()

# Redondear el resultado de 'puntaje_transformado' a un decimal
dominios_evaluaciones_y_usuarios['puntaje_transformado'] = dominios_evaluaciones_y_usuarios['puntaje_transformado'].round(1)



# Se filtran solo los dominios 
dominios_filtros = [
    'Liderazgo y relaciones sociales en el trabajo', 
    'Control sobre el trabajo', 
    'Demandas del trabajo', 
    'Recompensas'
]

dominios_evaluaciones_y_usuarios = dominios_evaluaciones_y_usuarios[dominios_evaluaciones_y_usuarios['dominio'].isin(dominios_filtros)].reset_index(drop=True)



'''3. Unión de las tablas 'usuarios', 'evaluaciones', 'resultados_cuestionarios' 
(para poder tener la información del resultado del puntaje_transformado por área y por tipo de empleado (A o B))'''


conn = sqlite3.connect('../data/evaluacion_psicosocial.db')

# Leer las tablas de interés
evaluaciones3_df = pd.read_sql("SELECT * FROM evaluaciones", conn)
resultados_cuestionarios_df = pd.read_sql("SELECT * FROM resultados_cuestionarios", conn)
usuarios3_df = pd.read_sql("SELECT * FROM usuarios", conn)

# columnas de interés de la tabla usuarios para anonimizar usuarios y no traer cédula y nombre
usuarios3_df = usuarios3_df[['id', 'area']]

# Cambiar el nombre de la columna 'id' a 'usuario_id' en la tabla usuarios para poder hacer la unión
usuarios3_df.rename(columns={'id': 'usuario_id'}, inplace=True)

# Unir las tablas por 'usuario_id'
resultados_con_evaluaciones = pd.merge(resultados_cuestionarios_df, evaluaciones3_df, on='usuario_id', how='inner')
resultados_evaluaciones_y_usuarios = pd.merge(resultados_con_evaluaciones, usuarios3_df, on='usuario_id', how='inner')

conn.close()

#Convertir a mayúsculas los valores de la columna tipo_empleado
resultados_evaluaciones_y_usuarios['tipo_empleado'] = resultados_evaluaciones_y_usuarios['tipo_empleado'].str.upper()

# Eliminar filas donde 'puntaje_bruto' y/o 'puntaje_transformado' sean NaN
resultados_evaluaciones_y_usuarios = resultados_evaluaciones_y_usuarios.dropna(subset=['puntaje_bruto', 'puntaje_transformado'])



#Se saca promedio de puntaje_transformado teniendo en cuenta tipo de cuestionario, tipo de empleado y área
resultados_evaluaciones_y_usuarios2 = resultados_evaluaciones_y_usuarios.groupby(['tipo_cuestionario', 'tipo_empleado', 'area']).agg({
    'puntaje_transformado': 'mean'
}).reset_index()

# Redondear el resultado de 'puntaje_transformado' a un decimal
resultados_evaluaciones_y_usuarios2['puntaje_transformado'] = resultados_evaluaciones_y_usuarios2['puntaje_transformado'].round(1)

# Calcular el promedio total de la empresa sin considerar el área
resultados_totales = resultados_evaluaciones_y_usuarios.groupby(['tipo_cuestionario', 'tipo_empleado']).agg({
    'puntaje_transformado': 'mean'
}).reset_index()

# Redondear los valores a un decimal
resultados_totales['puntaje_transformado'] = resultados_totales['puntaje_transformado'].round(1)


# Conectar a la base de datos
conn = sqlite3.connect('../data/evaluacion_psicosocial.db')

# Consulta SQL para obtener empleados con Riesgo Alto o Muy Alto en cualquier cuestionario
query = """
SELECT u.nombre, u.identificacion, u.area, e.tipo_empleado, r.tipo_cuestionario, 
       r.puntaje_bruto, r.puntaje_transformado, r.clasificacion
FROM resultados_cuestionarios r
JOIN evaluaciones e ON r.usuario_id = e.usuario_id
JOIN usuarios u ON r.usuario_id = u.id
WHERE r.clasificacion IN ('Riesgo alto', 'Riesgo muy alto', 'Alto', 'Muy alto')
"""

# Ejecutar la consulta y cargar los datos en un DataFrame
empleados_riesgo = pd.read_sql(query, conn)

# Cerrar la conexión
conn.close()

#Convertir a mayúsculas los valores de la columna tipo_empleado y nombre

empleados_riesgo['nombre'] = empleados_riesgo['nombre'].str.upper()
empleados_riesgo['tipo_empleado'] = empleados_riesgo['tipo_empleado'].str.upper()

'''4. Generar funciones para asignar clasificaciones a cada tabla'''


#para resultados_cuestionarios ********************************************************************

# Función para clasificar 'Estrés'
def clasificar_estres(row):
    if row['tipo_empleado'] == 'A':
        for rango in clasificacion_estres_A:
            if rango[0] <= row['puntaje_transformado'] <= rango[1]:
                return rango[2]
    elif row['tipo_empleado'] == 'B':
        for rango in clasificacion_estres_B:
            if rango[0] <= row['puntaje_transformado'] <= rango[1]:
                return rango[2]
    return np.nan

# Función para clasificar 'Intralaboral'
def clasificar_intralaboral(row):
    if row['tipo_empleado'] == 'A':
        for rango in CLASIFICACION_CUESTIONARIO_A:
            if rango[0] <= row['puntaje_transformado'] <= rango[1]:
                return rango[2]
    elif row['tipo_empleado'] == 'B':
        for rango in CLASIFICACION_CUESTIONARIO_B:
            if rango[0] <= row['puntaje_transformado'] <= rango[1]:
                return rango[2]
    return np.nan

# Función para clasificar 'Extralaboral'
def clasificar_extralaboral(row):
    for rango in CLASIFICACION_CUESTIONARIO_E:
        if rango[0] <= row['puntaje_transformado'] <= rango[1]:
            return rango[2]
    return np.nan

# Función para clasificar 'A + Extralaboral' y 'B + Extralaboral'
def clasificar_a_b_extralaboral(row):
    if row['tipo_cuestionario'] in CLASIFICACION_CUESTIONARIOS:
        for rango in CLASIFICACION_CUESTIONARIOS[row['tipo_cuestionario']]:
            if rango[0] <= row['puntaje_transformado'] <= rango[1]:
                return rango[2]
    return np.nan

# Función principal para asignar la clasificación
def asignar_clasificacion(row):
    if row['tipo_cuestionario'] == 'Estrés':
        return clasificar_estres(row)
    elif row['tipo_cuestionario'] == 'Intralaboral':
        return clasificar_intralaboral(row)
    elif row['tipo_cuestionario'] == 'Extralaboral':
        return clasificar_extralaboral(row)
    elif row['tipo_cuestionario'] in ['A + Extralaboral', 'B + Extralaboral']:
        return clasificar_a_b_extralaboral(row)
    return np.nan

# Crear la columna 'clasificacion' con valores predeterminados (NaN)
resultados_evaluaciones_y_usuarios2['clasificacion'] = np.nan

# Aplicar la función para llenar la columna 'clasificacion'
resultados_evaluaciones_y_usuarios2['clasificacion'] = resultados_evaluaciones_y_usuarios2.apply(asignar_clasificacion, axis=1)

# Crear la columna 'clasificacion' con valores predeterminados (NaN)
resultados_totales['clasificacion'] = np.nan

# Aplicar la función para llenar la columna 'clasificacion'
resultados_totales['clasificacion'] = resultados_totales.apply(asignar_clasificacion, axis=1)


#Para dominios ********************************************************************

# Función para clasificar dominios
def clasificar_dominios(row):
    if row['tipo_empleado'] == 'A':
        if row['dominio'] in CLASIFICACION_DOMINIOS_A:
            for rango in CLASIFICACION_DOMINIOS_A[row['dominio']]:
                if rango[0] <= row['puntaje_transformado'] <= rango[1]:
                    return rango[2]
    elif row['tipo_empleado'] == 'B':
        if row['dominio'] in CLASIFICACION_DOMINIOS_B:
            for rango in CLASIFICACION_DOMINIOS_B[row['dominio']]:
                if rango[0] <= row['puntaje_transformado'] <= rango[1]:
                    return rango[2]
    return np.nan  # Devolver NaN si no hay clasificación definida

# Función principal para asignar la clasificación
def asignar_clasificacion_dominios(row):
    return clasificar_dominios(row)

# Crear la columna 'clasificacion' con valores predeterminados (NaN)
dominios_evaluaciones_y_usuarios['clasificacion'] = np.nan

# Aplicar la función para llenar la columna 'clasificacion'
dominios_evaluaciones_y_usuarios['clasificacion'] = dominios_evaluaciones_y_usuarios.apply(asignar_clasificacion_dominios, axis=1)



#Para dimensiones ********************************************************************

# Función para clasificar dimensiones
def clasificar_dimensiones(row):
    if row['dimension'] in CLASIFICACION_DIMENSIONES_E:
        for rango in CLASIFICACION_DIMENSIONES_E[row['dimension']]:
            if rango[0] <= row['puntaje_transformado'] <= rango[1]:
                return rango[2]
    elif row['tipo_empleado'] == 'A':
        if row['dimension'] in CLASIFICACION_DIMENSIONES_A:
            for rango in CLASIFICACION_DIMENSIONES_A[row['dimension']]:
                if rango[0] <= row['puntaje_transformado'] <= rango[1]:
                    return rango[2]
    elif row['tipo_empleado'] == 'B':
        if row['dimension'] in CLASIFICACION_DIMENSIONES_B:
            for rango in CLASIFICACION_DIMENSIONES_B[row['dimension']]:
                if rango[0] <= row['puntaje_transformado'] <= rango[1]:
                    return rango[2]
    return np.nan  # Devolver NaN si no hay clasificación definida

# Función principal para asignar la clasificación
def asignar_clasificacion_dimensiones(row):
    return clasificar_dimensiones(row)

# Crear la columna 'clasificacion' con valores predeterminados (NaN)
dimensiones_evaluaciones_y_usuarios['clasificacion'] = np.nan

# Aplicar la función para llenar la columna 'clasificacion'
dimensiones_evaluaciones_y_usuarios['clasificacion'] = dimensiones_evaluaciones_y_usuarios.apply(asignar_clasificacion_dimensiones, axis=1)


'''Guardar las tablas finales en un archivo de excel con una hoja correspondiente a cada tabla'''


ruta_guardado = '../resultado_gral_excel/clasificaciones_gral6.xlsx'

# Crear la carpeta si no existe
carpeta_guardado = os.path.dirname(ruta_guardado)
if not os.path.exists(carpeta_guardado):
    os.makedirs(carpeta_guardado)

# Exportar tablas a archivo excel cada tabla en una hoja 
with pd.ExcelWriter(ruta_guardado) as writer:
    dimensiones_evaluaciones_y_usuarios.to_excel(writer, sheet_name='Promedios Dimensiones', index=False)
    dominios_evaluaciones_y_usuarios.to_excel(writer, sheet_name='Promedios Dominios', index=False)
    resultados_evaluaciones_y_usuarios2.to_excel(writer, sheet_name='Promedios Cuestionarios', index=False)
    resultados_totales.to_excel(writer, sheet_name='Total Empresa', index=False)
    empleados_riesgo.to_excel(writer, sheet_name='Riesgos Altos', index=False)

# Cargar el archivo para editarlo con openpyxl
wb = load_workbook(ruta_guardado)

# Definir estilos generales
thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))

header_fill = PatternFill(start_color="1F497D", end_color="1F497D", fill_type="solid")  # Azul oscuro para encabezados
cell_fill = PatternFill(start_color="BFD9ED", end_color="BFD9ED", fill_type="solid")  # Azul claro para el fondo normal

header_font = Font(bold=True, color="FFFFFF", size=14)  # Letra blanca, negrita y grande para encabezados
default_font = Font(size=11)  # Fuente normal para el resto del contenido

header_alignment = Alignment(horizontal="center", vertical="center")  # Centrar encabezados
content_alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)  # Alinear contenido a la izquierda

# Definir colores ajustados para el semáforo de riesgo
colores_riesgo = {
    "Sin riesgo o riesgo despreciable": "5D9C59",  # Verde medio oscuro
    "Muy bajo": "7DC77D",  # Verde más notorio
    "Riesgo bajo": "A0D699",  # Verde intermedio
    "Bajo": "A0D699",  # Verde intermedio
    "Riesgo medio": "FFC000",  # Amarillo mostaza
    "Medio": "FFC000",  # Amarillo mostaza
    "Riesgo alto": "FF4500",  # Naranja fuerte
    "Alto": "FF4500",  # Naranja fuerte
    "Riesgo muy alto": "FF0000",  # Rojo intenso
    "Muy alto": "FF0000"  # Rojo intenso
}

# Aplicar formato a todas las hojas
for sheet in wb.sheetnames:
    ws = wb[sheet]

    # Ajustar el ancho de las columnas en base al contenido
    column_widths = {}
    for row in ws.iter_rows():
        for cell in row:
            if cell.value:
                column_widths[cell.column_letter] = max(column_widths.get(cell.column_letter, 0), len(str(cell.value)))

    for col_letter, width in column_widths.items():
        ws.column_dimensions[col_letter].width = width + 4  # Se añade un pequeño margen

    # Aplicar estilos a los encabezados
    for cell in ws[1]:  # Primera fila (encabezados)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = header_alignment

    # Aplicar formato al resto de las celdas
    for row in ws.iter_rows(min_row=2):  # Desde la segunda fila en adelante
        for cell in row:
            if cell.column_letter not in ["clasificacion"]:  # Evitar cambiar el fondo de clasificación
                cell.fill = cell_fill  # Aplicar azul claro a todo excepto clasificaciones

            if cell.value and isinstance(cell.value, str):  # Verifica si es texto
                texto = cell.value.strip()  # Eliminar espacios en blanco extra
                if texto in colores_riesgo:  # Si el texto está en el diccionario de colores
                    cell.fill = PatternFill(start_color=colores_riesgo[texto], end_color=colores_riesgo[texto], fill_type="solid")

            cell.border = thin_border
            cell.alignment = content_alignment
            cell.font = default_font

# Guardar los cambios
wb.save(ruta_guardado)

print('Proceso terminado con éxito')