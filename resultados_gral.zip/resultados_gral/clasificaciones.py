# Clasificaciones para 'Estrés' ******************************************
clasificacion_estres_A = [
    (0.0, 7.8, "Muy bajo"),
    (7.9, 12.6, "Bajo"),
    (12.7, 17.7, "Medio"),
    (17.8, 25.0, "Alto"),
    (25.1, 100, "Muy alto"),
]

clasificacion_estres_B = [
    (0.0, 6.5, "Muy bajo"),
    (6.6, 11.8, "Bajo"),
    (11.9, 17.0, "Medio"),
    (17.1, 23.4, "Alto"),
    (23.5, 100, "Muy alto"),
]

# Clasificaciones para 'Intralaboral'  ******************************************
CLASIFICACION_CUESTIONARIO_A = [
    (0.0, 19.7, "Sin riesgo o riesgo despreciable"),
    (19.8, 25.8, "Riesgo bajo"),
    (25.9, 31.5, "Riesgo medio"),
    (31.6, 38.0, "Riesgo alto"),
    (38.1, 100, "Riesgo muy alto"),
]

CLASIFICACION_CUESTIONARIO_B = [
    (0.0, 19.9, "Sin riesgo o riesgo despreciable"),
    (20.0, 24.8, "Riesgo bajo"),
    (24.9, 29.5, "Riesgo medio"),
    (29.6, 35.4, "Riesgo alto"),
    (35.5, 100, "Riesgo muy alto"),
]

# Clasificaciones para 'Extralaboral'   ******************************************
CLASIFICACION_CUESTIONARIO_E = [
    (0.0, 11.3, "Sin riesgo o riesgo despreciable"),
    (11.4, 16.9, "Riesgo bajo"),
    (17.0, 22.6, "Riesgo medio"),
    (22.7, 29.0, "Riesgo alto"),
    (29.1, 100, "Riesgo muy alto"),
]

# Clasificaciones para 'A + Extralaboral' y 'B + Extralaboral'   ******************************************
CLASIFICACION_CUESTIONARIOS = {
    "A + Extralaboral": [
        (0.0, 18.8, "Sin riesgo o riesgo despreciable"),
        (18.9, 24.4, "Riesgo bajo"),
        (24.5, 29.5, "Riesgo medio"),
        (29.6, 35.4, "Riesgo alto"),
        (35.5, 100, "Riesgo muy alto")
    ],
    "B + Extralaboral": [
        (0.0, 19.9, "Sin riesgo o riesgo despreciable"),
        (20.0, 24.8, "Riesgo bajo"),
        (24.9, 29.5, "Riesgo medio"),
        (29.6, 35.4, "Riesgo alto"),
        (35.5, 100, "Riesgo muy alto")
    ]
}

# Clasificaciones para dominios (tipo_empleado A)  ******************************************
CLASIFICACION_DOMINIOS_A = {
    "Liderazgo y relaciones sociales en el trabajo": [
        (0.0, 9.1, "Sin riesgo o riesgo despreciable"),
        (9.2, 17.7, "Riesgo bajo"),
        (17.8, 25.6, "Riesgo medio"),
        (25.7, 34.8, "Riesgo alto"),
        (34.9, 100, "Riesgo muy alto")
    ],
    "Control sobre el trabajo": [
        (0.0, 10.7, "Sin riesgo o riesgo despreciable"),
        (10.8, 19.0, "Riesgo bajo"),
        (19.1, 29.8, "Riesgo medio"),
        (29.9, 40.5, "Riesgo alto"),
        (40.6, 100, "Riesgo muy alto")
    ],
    "Demandas del trabajo": [
        (0.0, 28.5, "Sin riesgo o riesgo despreciable"),
        (28.6, 35.0, "Riesgo bajo"),
        (35.1, 41.5, "Riesgo medio"),
        (41.6, 47.5, "Riesgo alto"),
        (47.6, 100, "Riesgo muy alto")
    ],
    "Recompensas": [
        (0.0, 4.5, "Sin riesgo o riesgo despreciable"),
        (4.6, 11.4, "Riesgo bajo"),
        (11.5, 20.5, "Riesgo medio"),
        (20.6, 29.5, "Riesgo alto"),
        (29.6, 100, "Riesgo muy alto")
    ]
}

# Clasificaciones para dominios (tipo_empleado B)  ******************************************
CLASIFICACION_DOMINIOS_B = {
    "Liderazgo y relaciones sociales en el trabajo": [
        (0.0, 8.3, "Sin riesgo o riesgo despreciable"),
        (8.4, 17.5, "Riesgo bajo"),
        (17.6, 26.7, "Riesgo medio"),
        (26.8, 38.3, "Riesgo alto"),
        (38.4, 100, "Riesgo muy alto")
    ],
    "Control sobre el trabajo": [
        (0.0, 19.4, "Sin riesgo o riesgo despreciable"),
        (19.5, 26.4, "Riesgo bajo"),
        (26.5, 34.7, "Riesgo medio"),
        (34.8, 43.1, "Riesgo alto"),
        (43.2, 100, "Riesgo muy alto")
    ],
    "Demandas del trabajo": [
        (0.0, 26.9, "Sin riesgo o riesgo despreciable"),
        (27.0, 33.3, "Riesgo bajo"),
        (33.4, 37.8, "Riesgo medio"),
        (37.9, 44.2, "Riesgo alto"),
        (44.3, 100, "Riesgo muy alto")
    ],
    "Recompensas": [
        (0.0, 2.5, "Sin riesgo o riesgo despreciable"),
        (2.6, 10.0, "Riesgo bajo"),
        (10.1, 17.5, "Riesgo medio"),
        (17.6, 27.5, "Riesgo alto"),
        (27.6, 100, "Riesgo muy alto")
    ]
}

#Clasificaciones para dimensiones (tipo_empleado A)  ******************************************
CLASIFICACION_DIMENSIONES_A = {
    "Caracteristicas del liderazgo": [(0.0, 3.8, "Sin riesgo o riesgo despreciable"),
                                      (3.9, 15.4, "Riesgo bajo"),
                                      (15.5, 30.8, "Riesgo medio"),
                                      (30.9, 46.2, "Riesgo alto"),
                                      (46.3, 100, "Riesgo muy alto")],

    "Relaciones sociales en el trabajo": [(0.0, 5.4, "Sin riesgo o riesgo despreciable"),
                                          (5.5, 16.1, "Riesgo bajo"),
                                          (16.2, 25.0, "Riesgo medio"),
                                          (25.1, 37.5, "Riesgo alto"),
                                          (37.6, 100, "Riesgo muy alto")],

    "Retroalimentacion del desempeño": [(0.0, 10.0, "Sin riesgo o riesgo despreciable"),
                                        (10.1, 25.0, "Riesgo bajo"),
                                        (25.1, 40.0, "Riesgo medio"),
                                        (40.1, 55.0, "Riesgo alto"),
                                        (55.1, 100, "Riesgo muy alto")],

    "Relacion con los colaboradores": [(0.0, 13.9, "Sin riesgo o riesgo despreciable"),
                                       (14.0, 25.0, "Riesgo bajo"),
                                       (25.1, 33.3, "Riesgo medio"),
                                       (33.4, 47.2, "Riesgo alto"),
                                       (47.3, 100, "Riesgo muy alto")],

    "Claridad de rol": [(0.0, 0.9, "Sin riesgo o riesgo despreciable"),
                        (1.0, 10.7, "Riesgo bajo"),
                        (10.8, 21.4, "Riesgo medio"),
                        (21.5, 39.3, "Riesgo alto"),
                        (39.4, 100, "Riesgo muy alto")],

    "Capacitacion": [(0.0, 0.9, "Sin riesgo o riesgo despreciable"),
                     (1.0, 16.7, "Riesgo bajo"),
                     (16.8, 33.3, "Riesgo medio"),
                     (33.4, 50.0, "Riesgo alto"),
                     (50.1, 100, "Riesgo muy alto")],

    "Participacion y manejo del cambio": [(0.0, 12.5, "Sin riesgo o riesgo despreciable"),
                                          (12.6, 25.0, "Riesgo bajo"),
                                          (25.1, 37.5, "Riesgo medio"),
                                          (37.6, 50.0, "Riesgo alto"),
                                          (50.1, 100, "Riesgo muy alto")],

    "Oportunidades para el uso y desarrollo de habilidades y conocimientos": 
                                          [(0.0, 0.9, "Sin riesgo o riesgo despreciable"),
                                          (1.0, 6.3, "Riesgo bajo"),
                                          (6.4, 18.8, "Riesgo medio"),
                                          (18.9, 31.3, "Riesgo alto"),
                                          (31.4, 100, "Riesgo muy alto")],

    "Control y autonomia sobre el trabajo": [(0.0, 8.3, "Sin riesgo o riesgo despreciable"),
                                             (8.4, 25.0, "Riesgo bajo"),
                                             (25.1, 41.7, "Riesgo medio"),
                                             (41.8, 58.3, "Riesgo alto"),
                                             (58.4, 100, "Riesgo muy alto")],

    "Demandas ambientales y de esfuerzo fisico": [(0.0, 14.6, "Sin riesgo o riesgo despreciable"), 
                                                  (14.7, 22.9, "Riesgo bajo"),
                                                  (23.0, 31.3, "Riesgo medio"),
                                                  (31.4, 39.6, "Riesgo alto"),
                                                  (39.7, 100, "Riesgo muy alto")],

    "Demandas emocionales": [(0.0, 16.7, "Sin riesgo o riesgo despreciable"),
                             (16.8, 25.0, "Riesgo bajo"),
                             (25.1, 33.3, "Riesgo medio"),
                             (33.4, 47.2, "Riesgo alto"),
                             (47.3, 100, "Riesgo muy alto")],

    "Demandas cuantitativas": [(0.0, 25.0, "Sin riesgo o riesgo despreciable"),
                               (25.1, 33.3, "Riesgo bajo"),
                               (33.4, 45.8, "Riesgo medio"),
                               (45.9, 54.2, "Riesgo alto"),
                               (54.3, 100, "Riesgo muy alto")],

    "Influencia del trabajo sobre el entorno extralaboral": [(0.0, 18.8, "Sin riesgo o riesgo despreciable"),
                                                            (18.9, 31.3, "Riesgo bajo"),
                                                            (31.4, 43.8, "Riesgo medio"),
                                                            (43.9, 50.0, "Riesgo alto"),
                                                            (50.1, 100, "Riesgo muy alto")],

    "Exigencias de responsabilidad del cargo": [(0.0, 37.5, "Sin riesgo o riesgo despreciable"),
                                                (37.6, 54.2, "Riesgo bajo"),
                                                (54.3, 66.7, "Riesgo medio"),
                                                (66.8, 79.2, "Riesgo alto"),
                                                (79.3, 100, "Riesgo muy alto")],

    "Demandas de carga mental": [(0.0, 60.0, "Sin riesgo o riesgo despreciable"),
                                 (60.1, 70.0, "Riesgo bajo"),
                                 (70.1, 80.0, "Riesgo medio"),
                                 (80.1, 90.0, "Riesgo alto"),
                                 (90.1, 100, "Riesgo muy alto")],

    "Consistencia de rol": [(0.0, 15.0, "Sin riesgo o riesgo despreciable"),
                            (15.1, 25.0, "Riesgo bajo"),
                            (25.1, 35.0, "Riesgo medio"),
                            (35.1, 45.0, "Riesgo alto"),
                            (45.1, 100, "Riesgo muy alto")],

    "Demandas de la jornada de trabajo": [(0.0, 8.3, "Sin riesgo o riesgo despreciable"),
                                          (8.4, 25.0, "Riesgo bajo"),
                                          (25.1, 33.3, "Riesgo medio"),
                                          (33.4, 50.0, "Riesgo alto"),
                                          (50.1, 100, "Riesgo muy alto")],

    "Recompensas derivadas de la pertenencia a la organizacion y del trabajo que se realiza": [
        (0.0, 0.9, "Sin riesgo o riesgo despreciable"),
        (1.0, 5.0, "Riesgo bajo"),
        (5.1, 10.0, "Riesgo medio"),
        (10.1, 20.0, "Riesgo alto"),
        (20.1, 100, "Riesgo muy alto")
    ],

    "Reconocimiento y compensacion": [(0.0, 4.2, "Sin riesgo o riesgo despreciable"),
                                      (4.3, 16.7, "Riesgo bajo"),
                                      (16.8, 25.0, "Riesgo medio"),
                                      (29.9 , 40.5,  "Riesgo alto"),
                                      (37.6, 100, "Riesgo muy alto")]
}


#Clasificaciones para dimensiones (tipo_empleado B)  ******************************************
CLASIFICACION_DIMENSIONES_B = {
    "Caracteristicas del liderazgo": [(0.0, 3.8, "Sin riesgo o riesgo despreciable"),
                                      (3.9, 13.5, "Riesgo bajo"),
                                      (13.6, 25.0, "Riesgo medio"),
                                      (25.1, 38.5, "Riesgo alto"),
                                      (38.6, 100, "Riesgo muy alto")],

    "Relaciones sociales en el trabajo": [(0.0, 6.3, "Sin riesgo o riesgo despreciable"),
                                          (6.4, 14.6, "Riesgo bajo"),
                                          (14.7, 27.1, "Riesgo medio"),
                                          (27.2, 37.5, "Riesgo alto"),
                                          (37.6, 100, "Riesgo muy alto")],

    "Retroalimentacion del desempeño": [(0.0, 5.0, "Sin riesgo o riesgo despreciable"),
                                        (5.1, 20.0, "Riesgo bajo"),
                                        (20.1, 30.0, "Riesgo medio"),
                                        (30.1, 50.0, "Riesgo alto"),
                                        (50.1, 100, "Riesgo muy alto")],

    "Claridad de rol": [(0.0, 0.9, "Sin riesgo o riesgo despreciable"),
                        (1.0, 5.0, "Riesgo bajo"),
                        (5.1, 15.0, "Riesgo medio"),
                        (15.1, 30.0, "Riesgo alto"),
                        (30.1, 100, "Riesgo muy alto")],

    "Capacitacion": [(0.0, 0.9, "Sin riesgo o riesgo despreciable"),
                     (1.0, 16.7, "Riesgo bajo"),
                     (16.8, 25.0, "Riesgo medio"),
                     (25.1, 50.0, "Riesgo alto"),
                     (50.1, 100, "Riesgo muy alto")],

    "Participacion y manejo del cambio": [(0.0, 16.7, "Sin riesgo o riesgo despreciable"),
                                          (16.8, 33.3, "Riesgo bajo"),
                                          (33.4, 41.7, "Riesgo medio"),
                                          (41.8, 58.3, "Riesgo alto"),
                                          (58.4, 100, "Riesgo muy alto")],

    "Oportunidades para el uso y desarrollo de habilidades y conocimientos": 
                                          [(0.0, 12.5, "Sin riesgo o riesgo despreciable"),
                                          (12.6, 25.0, "Riesgo bajo"),
                                          (25.1, 37.5, "Riesgo medio"),
                                          (37.6, 56.3, "Riesgo alto"),
                                          (56.4, 100, "Riesgo muy alto")],

    "Control y autonomia sobre el trabajo": [(0.0, 33.3, "Sin riesgo o riesgo despreciable"),
                                             (33.4, 50.0, "Riesgo bajo"),
                                             (50.1, 66.7, "Riesgo medio"),
                                             (66.8, 75.0, "Riesgo alto"),
                                             (75.1, 100, "Riesgo muy alto")],

    "Demandas ambientales y de esfuerzo fisico": [(0.0, 22.9, "Sin riesgo o riesgo despreciable"),
                                                  (23.0, 31.3, "Riesgo bajo"),
                                                  (31.4, 39.6, "Riesgo medio"),
                                                  (39.7, 47.9, "Riesgo alto"),
                                                  (48.0, 100, "Riesgo muy alto")],

    "Demandas emocionales": [(0.0, 19.4, "Sin riesgo o riesgo despreciable"),
                             (19.5, 27.8, "Riesgo bajo"),
                             (27.9, 38.9, "Riesgo medio"),
                             (39.0, 47.2, "Riesgo alto"),
                             (47.3, 100, "Riesgo muy alto")],

    "Demandas cuantitativas": [(0.0, 16.7, "Sin riesgo o riesgo despreciable"),
                               (16.8, 33.3, "Riesgo bajo"),
                               (33.4, 41.7, "Riesgo medio"),
                               (41.8, 50.0, "Riesgo alto"),
                               (50.1, 100, "Riesgo muy alto")],

    "Influencia del trabajo sobre el entorno extralaboral": [(0.0, 12.5, "Sin riesgo o riesgo despreciable"),
                                                            (12.6, 25.0, "Riesgo bajo"),
                                                            (25.1, 31.3, "Riesgo medio"),
                                                            (31.4, 50.0, "Riesgo alto"),
                                                            (50.1, 100, "Riesgo muy alto")],

    "Demandas de carga mental": [(0.0, 50.0, "Sin riesgo o riesgo despreciable"),
                                 (50.1, 65.0, "Riesgo bajo"),
                                 (65.1, 75.0, "Riesgo medio"),
                                 (75.1, 85.0, "Riesgo alto"),
                                 (85.1, 100, "Riesgo muy alto")],

    "Demandas de la jornada de trabajo": [(0.0, 25.0, "Sin riesgo o riesgo despreciable"),
                                          (25.1, 37.5, "Riesgo bajo"),
                                          (37.6, 45.8, "Riesgo medio"),
                                          (45.9, 58.3, "Riesgo alto"),
                                          (58.4, 100, "Riesgo muy alto")],

    "Recompensas derivadas de la pertenencia a la organizacion y del trabajo que se realiza": [
        (0.0, 0.9, "Sin riesgo o riesgo despreciable"),
        (1.0, 6.3, "Riesgo bajo"),
        (6.4, 12.5, "Riesgo medio"),
        (12.6, 18.8, "Riesgo alto"),
        (18.9, 100, "Riesgo muy alto")
    ],

    "Reconocimiento y compensacion": [(0.0, 0.9, "Sin riesgo o riesgo despreciable"),
                                      (1.0, 12.5, "Riesgo bajo"),
                                      (12.6, 25.0, "Riesgo medio"),
                                      (25.1, 37.5, "Riesgo alto"),
                                      (37.6, 100, "Riesgo muy alto")]
}


#Clasificaciones para dimensiones extralaboral  ******************************************
CLASIFICACION_DIMENSIONES_E = {
    "Tiempo fuera del trabajo": [(0.0, 6.3, "Sin riesgo o riesgo despreciable"),
                                 (6.4, 25.0, "Riesgo bajo"),
                                 (25.1, 37.5, "Riesgo medio"),
                                 (37.6, 50.0, "Riesgo alto"),
                                 (50.1, 100, "Riesgo muy alto")],
    "Relaciones familiares": [(0.0, 8.3, "Sin riesgo o riesgo despreciable"),
                              (8.4, 25.0, "Riesgo bajo"),
                              (25.1, 33.3, "Riesgo medio"),
                              (33.4, 50.0, "Riesgo alto"),
                              (50.1, 100, "Riesgo muy alto")],
    "Comunicación y relaciones interpersonales": [(0.0, 0.9, "Sin riesgo o riesgo despreciable"),
                                                  (1.0, 10.0, "Riesgo bajo"),
                                                  (10.1, 20.0, "Riesgo medio"),
                                                  (20.1, 30.0, "Riesgo alto"),
                                                  (30.1, 100, "Riesgo muy alto")],
    "Situación económica del grupo familiar": [(0.0, 8.3, "Sin riesgo o riesgo despreciable"),
                                               (8.4, 25.0, "Riesgo bajo"),
                                               (25.1, 33.3, "Riesgo medio"),
                                               (33.4, 50.0, "Riesgo alto"),
                                               (50.1, 100, "Riesgo muy alto")],
    "Características de la vivienda y de su entorno": [(0.0, 5.6, "Sin riesgo o riesgo despreciable"),
                                                       (5.7, 11.1, "Riesgo bajo"),
                                                       (11.2, 13.9, "Riesgo medio"),
                                                       (14.0, 22.2, "Riesgo alto"),
                                                       (22.3, 100, "Riesgo muy alto")],
    "Influencia del entorno extralaboral sobre el trabajo": [(0.0, 8.3, "Sin riesgo o riesgo despreciable"),
                                                            (8.4, 16.7, "Riesgo bajo"),
                                                            (16.8, 25.0, "Riesgo medio"),
                                                            (25.1, 41.7, "Riesgo alto"),
                                                            (41.8, 100, "Riesgo muy alto")],
    "Desplazamiento vivienda trabajo vivienda": [(0.0, 0.9, "Sin riesgo o riesgo despreciable"),
                                                 (1.0, 12.5, "Riesgo bajo"),
                                                 (12.6, 25.0, "Riesgo medio"),
                                                 (25.1, 43.8, "Riesgo alto"),
                                                 (43.9, 100, "Riesgo muy alto")]
}